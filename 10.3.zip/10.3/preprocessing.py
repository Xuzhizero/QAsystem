# -*- coding:utf-8 -*-


# !/usr/bin/python
# -*- coding: utf-8 -*-
import jieba as jb
import jieba.posseg as pseg  # 词性标注库
import jieba.analyse  # 基于 TF-IDF 算法
import numpy as np
from math import log
import pandas as pd

'''这是预处理部分'''


# 引入中文停用词库，进行过滤
def filtration(ls):  # 单个问题列表
    file = open('words_filtered_library.txt', 'r', encoding='utf8')
    t = file.readlines()
    ls_copy = ls.copy()
    for i in range(len(t)):
        t[i] = t[i].replace('\n', '')  # 去除停用词库中每行末尾的\n
    for i in ls_copy:
        if i in t:
            ls.remove(i)
    file.close()
    return ls


# 得到FAQ中问题方面的信息,包括问题总数.传入参数为语料库readlines后的列表
def info_Q(txt_lines):
    Q_list = []
    for line in txt_lines:
        if line[0] == 'Q':
            line = line.replace('\n', '')
            Q_list.append(line)
    return Q_list  # 这里Q_list中每个问题末尾都不含有\n


# 用于对语料库的问题进行分词,该部分代码由于目前较少，暂时在loadDataSet中直接使用
def division(txt):
    pass


# 加载文件,返回问题列表
def loadDataSet():
    f = open('./QA_DATA/QASET2.txt', 'r', encoding='utf8')
    t = f.readlines()
    Q_list = info_Q(t)
    postingList = []  # 每个元素为问题分词后的列表
    for q in Q_list:
        q_l = list(q)
        if ':' in q_l:  # 英文字符:
            del q_l[0:q_l.index(':') + 1:1]
        elif '：' in q_l:  # 中文字符冒号
            del q_l[0:q_l.index('：') + 1:1]
        q = ''.join(q_l)  # 之前几步是为了将Qxxx及：删除

        q = jb.lcut(q)  # 对每条问题进行分词
        postingList.append(q)
    for i in range(len(postingList)):
        postingList[i] = filtration(postingList[i])  # 去除停用词后的新postingList

    # 该出之后可以添加分类部分代码
    f.close()
    return postingList, Q_list


# 返回一个问句内分词和其权重的对应关系
def weight(q, wordls):  # 这里的wordls是postingList[i],q是Q_list[i]
    f = open('QA_DATA/KEY_WORDS.txt', 'r', encoding='utf8')  # 问点词词库
    ls = f.read().split(',')  # 问点词列表,每个元素都是一个问点词
    weight_dic = {}  # 对应关系：分词-权重
    for word in wordls:
        weight_dic[word] = 0.8
    # 现在得到了完整的字典，键为分词，值为权重（目前都视为一般关键词）
    # 将主题词的权重设为1
    keys = jieba.analyse.extract_tags(q, topK=3,
                                      allowPOS=('n', 'nr', 'ns', 'nt', 'nz', 'vn', 'ni', 'nl'))  # 返回的是主题词列表,设定只返回名词类型
    for key in keys:
        weight_dic[key] = 1  # 主题词的权重被设为1
    for i in weight_dic.keys():  # 主题词不可能是问点词,因为问点词不可能是名词
        if i in ls:
            weight_dic[i] = 0.9  # 问点词的权重被设为0.9
    f.close()
    return weight_dic


# 生成词向量。返回list_S,dic_tf_idf, list_weight_dic
def cal_weight(postingList, Q_list, myVocalbList):  # 问题已经过停用词库过滤
    f = open('QA_DATA/KEY_WORDS.txt', 'r', encoding='utf8')  # 问点词词库
    ls = f.read().split(',')  # 问点词列表,每个元素都是一个问点词

    list_weight_dic = []  # 每个问句生成一个weight_dic,合成一个列表list_weight_dic
    for i in range(len(Q_list)):
        weight_dic = weight(Q_list[i], postingList[i])
        list_weight_dic.append(weight_dic)

    dic_idf = {}  # 键为词汇表中每一个词，值为idf，即该词的反频率
    for i in myVocalbList:
        count = 0  # 用于计算包含词i的问句的个数
        for q in postingList:
            if i in q:
                count += 1
        idf_i = log((len(Q_list) / float(count)), 10)
        dic_idf[i] = idf_i
    # 现在得到了一个完整的idf字典，键为每一个词
    # 下面计算Si
    list_S = []  # 装载所有词向量的列表，将每一个问题转化为词向量后合成一个列表
    dic_tf_idf = {}  # 装载tf * idf的字典，键为词汇表中每一个词
    for j in range(len(Q_list)):
        S = [0] * len(postingList[j])  # S为词向量,数组类型，加快运算速度
        for i in range(len(postingList[j])):  # postingList[j][i]是一个问句中的某个分词
            tf_i = postingList[j].count(postingList[j][i]) / float(len(postingList[j]))  # 该词i的tf频率,即该词在该句子中出现的频率
            S[i] = list_weight_dic[j][postingList[j][i]] * tf_i * dic_idf[postingList[j][i]]  # 某一个问句中的某一个分词对应的Si
            S[i] = float('%.3f' % S[i])  # 保留3位小数
            dic_tf_idf[postingList[j][i]] = tf_i * dic_idf[postingList[j][i]]  # 此处有问题
        list_S.append(np.array(S))  # 转为数组类型，加快运算速度

    return list_S, dic_tf_idf, list_weight_dic, dic_idf


# 计算问句和每一个语料库中问题的相似度，合成一个列表
def Similarity(wordVecs, S_in):
    Simlist = []
    for S in wordVecs:
        Sim = (np.sum(np.multiply(S, S_in))) / (np.linalg.norm(S) * np.linalg.norm(S_in))
        Simlist.append(Sim)
    return Simlist


# 获得词汇表
def createVocabList(dataSet):  # 一个大列表，里面有小列表。postingList
    vocabSet = set([])
    for document in dataSet:
        vocabSet = vocabSet | set(document)  # 创建两个集合的并集
    return list(vocabSet)


# 生成词向量
def setOfWords2Vec(vocabList, inputSet, S):  # inputSet是问题列表，是postingList[j],S和inputSet同样尺寸
    returnVec = [0] * len(vocabList)
    for word in inputSet:
        if word in vocabList:
            returnVec[vocabList.index(word)] = S[inputSet.index(word)]  # 若有出现，则返回该分词对应的Si
        else:
            print("the word: %s is not in my Vocabulary!" % word)

    return returnVec


# 将所有问题生成的词向量合成一个列表
def createWords2Vecs(postingList, myVocalbList, list_S):  # list_S的尺寸和postingList一样
    wordVecs = []
    for j in range(len(postingList)):
        returnVec = setOfWords2Vec(myVocalbList, postingList[j], list_S[j])
        wordVecs.append(returnVec)
    return wordVecs


'''#生成词向量,1参数为词汇表，2参数为文档
def setOfWords2Vec(vocabList, inputSet):
    returnVec = [0] * len(vocabList)
    for word in inputSet:
        if word in vocabList:
            returnVec[vocabList.index(word)] = 1 #若有出现，则置1
        else:
            print("the word: %s is not in my Vocabulary!" % word)
    return returnVec'''


# 以下两个函数为输入端函数
def question_get():  # get questions
    q = input("你的问题是什么?\n")
    return q


def extract_key_word(question):  # 提取出关键词，合放在一个列表中
    ls = jb.lcut(question)
    ls = filtration(ls)
    return ls  # 这是一个列表


def createVec_input_q(vocabList, ls, dic_idf, q):  # 为输入问题建立词向量 ,ls是输入问题分词后的列表
    returnVec = [0] * len(vocabList)
    weight_dic = weight(q, ls)
    for word in ls:
        if word in vocabList:
            tf_i = ls.count(word) / float(len(ls))
            S_i = float('%.3f' % (weight_dic[word] * tf_i * dic_idf[word]))  # 保留3位小数
            returnVec[vocabList.index(word)] = S_i  # 若有出现，则返回该分词对应的Si
        else:
            pass
            '''print("the word: %s is not in my Vocabulary!" % word)'''
    return returnVec


def output_answer(q):  # 按照问题提供答案，这里我开发了txt打印指定行的算法
    f = open('语料库整理\问答语料对2.txt', 'r')
    num_this_q, num_next_q = 0, 0
    count_this, count_next = 0, 0
    txtList = list(enumerate(f))
    for num, line in txtList:  # num为行号，从0开始
        if line[0] == 'Q':
            line = line.replace('\n', '')
        if line == q:
            num_this_q = num
            count_this = 1
        if line[0] == 'Q' and num > num_this_q:
            num_next_q = num
            if count_this == 1:
                count_next = 1
        if count_this == 1 and count_next == 1:
            break

    answer = ''
    for i in range(num_this_q, num_next_q):
        answer += txtList[i][1]
    f.close()
    return answer


def main():
    postingList, Q_list = loadDataSet()
    Series_Qlist = pd.Series(Q_list)
    myVocalbList = createVocabList(postingList)
    list_S, dic_tf_idf, list_weight_dic, dic_idf = cal_weight(postingList, Q_list, myVocalbList)
    Series_S = pd.Series(list_S)  # 生成一个Series,用于给词向量赋予编号
    wordVecs = createWords2Vecs(postingList, myVocalbList, list_S)
    print('目前已收集%d个语料对' % len(Q_list))
    q = question_get()
    ls = extract_key_word(q)
    S_in = createVec_input_q(myVocalbList, ls, dic_idf, q)
    Simlist = Similarity(wordVecs, S_in)
    Series_Simlist = pd.Series(Simlist)
    q_possible_1st = Series_Qlist[Series_Simlist.idxmax()]
    print('你想问的问题是不是(回答Y或N):\n{}'.format(q_possible_1st))
    print("最高相似度:{:.3f}".format(Series_Simlist.max()))

    temp = input('请输入：\n')
    if temp == 'Y':
        answer_1st = output_answer(q_possible_1st)
        print(answer_1st)
    elif temp == 'N':
        print("以下有你想问的问题吗？若有，输入编号，若无，请输入'无'")
        q_possible_1_to_6 = Series_Simlist.sort_values(ascending=False)[1:6].index
        q_list = []
        for i in range(5):
            print("{}:{}".format(i, Series_Qlist[q_possible_1_to_6[i]]))
            q_list.append(Series_Qlist[q_possible_1_to_6[i]])
        zip_list = zip(range(5), q_list)
        temp1 = input('请输入：')
        if temp1 != '无':
            for num, q in list(zip_list):
                if num == int(temp1):
                    print(output_answer(q))
                    break
        else:
            print('是否想要换种问法？输入Y换种问法，N退出')
            temp2 = input('请输入：')
            if temp2 == 'N':
                print('已终止程序')
            elif temp2 == 'Y':
                main()
    else:
        print('输入有误，程序终止')
