# -*- coding:utf-8 -*-
import numpy as np
import jieba as jb
from data_base.data_get import *

def question_get(): # get questions
    q_string = input("你的问题是什么\n")
    return q_string

# 引入中文停用词库，进行过滤
def filtration(ls):  # 单个问题列表
    file = open('words_filtered_library.txt', 'r', encoding='utf8')
    t = file.readlines()
    ls_copy = ls.copy()
    for i in range(len(t)):
        t[i] = t[i].replace('\n', '')  # 去除停用词库中每行末尾的\n
    for i in ls_copy:
        if i in t:
            ls.remove(i)
    file.close()
    return ls

def extract_key_word(question): #提取出关键词，合放在一个列表中
    ls = jb.lcut(question) #初步分词
    filtered_q = filtration(ls)	#过滤一些分词,filtered_q为列表形式
    return filtered_q

# 返回一个问句内分词和其权重的对应关系
def weight(q, wordls):  # 这里的wordls是postingList[i],q是Q_list[i]
    f = open('QA_DATA/KEY_WORDS.txt', 'r', encoding='utf8')  # 问点词词库
    ls = f.read().split(',')  # 问点词列表,每个元素都是一个问点词
    weight_dic = {}  # 对应关系：分词-权重
    for word in wordls:
        weight_dic[word] = 0.8
    # 现在得到了完整的字典，键为分词，值为权重（目前都视为一般关键词）
    # 将主题词的权重设为1
    keys = jieba.analyse.extract_tags(q, topK=3,
                                      allowPOS=('n', 'nr', 'ns', 'nt', 'nz', 'vn', 'ni', 'nl'))  # 返回的是主题词列表,设定只返回名词类型
    for key in keys:
        weight_dic[key] = 1  # 主题词的权重被设为1
    for i in weight_dic.keys():  # 主题词不可能是问点词,因为问点词不可能是名词
        if i in ls:
            weight_dic[i] = 0.9  # 问点词的权重被设为0.9
    f.close()
    return weight_dic

#返回值dict1 {'Id4':tf-idf_4}
def build_dict1(idList, kList, idfList):  #idList [4, 6, 32, 354] 关键词在词汇表中编号
	dict1 = {}
	for i in len(range(idList)):
		tf = idList.count(idList[i])/len(idList)
		idf = idfList[i]
		k = kList[i]
		dict1[idList[i]] = k * tf * idf
	return dict1

def similarity(dict1, QIdList, Qdict2List):
	#Qdict2List: Q对应的字典列表[{'大学ID':tf-idf,'如何ID':tf-idf},{...},...]
	#dict2:单个Q的字典
	#QIdList Q在语料库中对应的Id列表
	SimList = []
	for i in QIdList:
		dict2 = Qdict2List[i]
		l_id = list(set(dict2.keys()&dict1.keys()))
		s = 0
		for j in l_id:
			s += dict2[l_id[j]] * dict1[l_id[j]]
		s2 = np.sqrt(sum(np.array(list(dict1.values()))**2))
		SimList.append(s1/s2)
	return SimList

if __name__ == "__main__":
    quest = question_get()

    key = extract_key_word(quest)
    #获取 词数据列表，问题id列表， 问题数据列表
    key_list, quest_list, q_v_list = qa_db_fetch(key)


