# -*- coding:utf-8 -*-

import pandas as pd
import numpy as np


def create_Qdict2List(postingList, Vocabrary):
	Qdict2List = []
	for i in range(len(postingList)):
		dict2 = {}
		for j in range(len(postingList[i])):
			tf = postingList[i].count(postingList[i][j]) / float(len(postingList[i]))  # 该词i的tf频率,即该词在该句子中出现的频率 
			Id = Vocabrary['vocabList'][Vocabrary['vocabList'].values == postingList[i][j]].index
			k_tf_idf = round(float(Vocabrary.loc[Id,'k_List'] * tf * Vocabrary.loc[Id,'idf_List']),3)
			dict2[j] = k_tf_idf
		Qdict2List.append(dict2)
	return Qdict2List

def output_answer(q):  # 按照问题提供答案，这里我开发了txt打印指定行的算法
    f = open('./QA_DATA/QASET2.txt', 'r', encoding='utf8')
    num_this_q, num_next_q = 0, 0
    count_this, count_next = 0, 0
    txtList = list(enumerate(f))
    for num, line in txtList:  # num为行号，从0开始
        if line[0] == 'Q':
            line = line.replace('\n', '')
        if line == q:
            num_this_q = num
            count_this = 1
        if line[0] == 'Q' and num > num_this_q:
            num_next_q = num
            if count_this == 1:
                count_next = 1
        if count_this == 1 and count_next == 1:
            break

    answer = ''
    for i in range(num_this_q, num_next_q):
        answer += txtList[i][1]
    f.close()
    return answer

def create_Answerlist(Q_list):
	Answerlist = []
	for i in range(len(Q_list)):
		answer = output_answer(Q_list[i])
		Answerlist.append(answer)
	return Answerlist


def build_sheet2(Qdict2List, Answerlist):
	sheet2 = pd.DataFrame({'Answerlist':Answerlist,'Qdict2List':Qdict2List})
	return sheet2


