# -*- coding:utf-8 -*-

from original import *
import sheet

postingList, Q_list = loadDataSet()
vocabList = createVocabList(postingList)
k_List = create_k_List(vocabList)
idf_List = create_idf_List(vocabList, postingList)
QList = create_QList(vocabList, postingList)
#print(postingList,'\n',vocabList)
Vocabrary = build_Vocabrary(vocabList, k_List, idf_List, QList)
print(Vocabrary)

Qdict2List = sheet.create_Qdict2List(postingList, Vocabrary)
Answerlist = sheet.create_Answerlist(Q_list)
sheet2 = sheet.build_sheet2(Qdict2List, Answerlist)
print(sheet2)
print(float(Vocabrary['k_List'][0  ]))
dc = DbConnect()
for i in range(len(Q_list)):
    dc.qav_insert('qa_sets', [i, Q_list[i], sheet2['Answerlist'][i], json.dumps(sheet2['Qdict2List'][i])])
    print('import qa', str(i), ' ok')
for i in range(len(vocabList)):
    dc.qav_insert('key_dict', [i, Vocabrary['vocabList'][i], float(Vocabrary['k_List'][i]), float(Vocabrary['idf_List'][i]), json.dumps(Vocabrary['QList'][i])])
    print('import key', str(i), ' ok')

dc.db_disconnect()