import MySQLdb as mdb
import json

def str_form(i, blanket = True):
    temp_str = ''
    for i in range(i-1):
        temp_str = temp_str + '%s,'
    temp_str = temp_str + '%s'
    if blanket:
        temp_str = "(%s)"%temp_str
    return temp_str

class DbConnect:
    def __init__(self):
        # 连接数据库
        config_json = open('./data_base/data_base_config.json','r')
        config = json.load(config_json)
        self.conn = mdb.connect(**config)
        # 使用cursor()方法获取操作游标
        self.cursor = self.conn.cursor()
        # 因该模块底层其实是调用CAPI的，所以，需要先得到当前指向数据库的指针。

    def qav_insert(self, chart_name, value_list):
        try:
            # 不建议直接拼接sql，占位符方面可能会出问题，execute提供了直接传值
            value = value_list
            value_str = ' values('
            for i in range(len(value_list)-1):
                value_str = value_str + '%s,'
            value_str = value_str + '%s)'

            self.cursor.execute('INSERT INTO ' + chart_name + value_str, value)

            # 如果没有设置自动提交事务，则这里需要手动提交一次
            self.conn.commit()
        except:
            import traceback

            traceback.print_exc()
            # 发生错误时会滚
            self.conn.rollback()

    def db_search(self, chart_name, columns, key_column, value_list):
        try:
            # 不建议直接拼接sql，占位符方面可能会出问题，execute提供了直接传值
            value_str = str_form(len(value_list))

            self.cursor.execute('select ' + columns + ' from ' + chart_name + ' where ' + key_column + ' in ' + value_str, value_list)

            return self.cursor.fetchall()
        except:
            import traceback

            traceback.print_exc()
            # 发生错误时会滚
            self.conn.rollback()

    def db_disconnect(self):
        # 关闭游标连接
        self.cursor.close()
        # 关闭数据库连接
        self.conn.close()
