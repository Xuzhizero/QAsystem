from data_base.database import DbConnect
import json
class key_word:
    def __init__(self, key_list):
        self.id = key_list[0]
        self.key = key_list[1]
        self.k = key_list[2]
        self.idf = key_list[3]
        self.q_list = eval(key_list[4])

def qa_db_fetch(q_vocab_list):
    dc = DbConnect()

    #找到关键词数据
    key_data = dc.db_search('key_dict', '*', 'key_word', q_vocab_list)
    key_list = []
    for key in key_data:
        print(key)
        key_item = key_word(key)
        key_list.append(key_item)

    #生成问题id列表
    quest_list = []
    dict_q = {}
    for k in key_list:
        quest_list = quest_list + k.q_list
    #去重
    quest_list = list(set(quest_list))

    #获取问题向量
    vector_list = dc.db_search('qa_sets', 'vector', 'qid', quest_list)
    v_list = []
    for v in vector_list:
        v_list.append(json.loads(v[0]))

    dc.db_disconnect()
    return key_list, quest_list, v_list