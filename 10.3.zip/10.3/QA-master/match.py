# -*- coding:utf-8 -*-

import jieba as jb
import jieba.posseg as pseg  #词性标注库
import jieba.analyse  #基于 TF-IDF 算法
import numpy as np
from math import log
import pandas as pd

import terminal


#生成词向量
def setOfWords2Vec(vocabList, inputSet,S): #inputSet是问题列表，是postingList[j],S和inputSet同样尺寸
    returnVec = [0] * len(vocabList)
    for word in inputSet:
        if word in vocabList:
            returnVec[vocabList.index(word)] = S[inputSet.index(word)] #若有出现，则返回该分词对应的Si
        else:
            print("the word: %s is not in my Vocabulary!" % word)

    return returnVec

#将所有问题生成的词向量合成一个列表
def createWords2Vecs(postingList,myVocalbList,list_S): #list_S的尺寸和postingList一样
    wordVecs = []
    for j in range(len(postingList)):
        returnVec = setOfWords2Vec(myVocalbList, postingList[j],list_S[j])
        wordVecs.append(returnVec)
    return wordVecs

def createVec_input_q(vocabList,ls,dic_idf,q): #为输入问题建立词向量 ,ls是输入问题分词后的列表
    returnVec = [0] * len(vocabList)
    weight_dic = weight(q, ls)
    for word in ls:
        if word in vocabList:
            tf_i = ls.count(word)/float(len(ls))
            S_i = float('%.3f' % (weight_dic[word] * tf_i * dic_idf[word]))  # 保留3位小数
            returnVec[vocabList.index(word)] = S_i #若有出现，则返回该分词对应的Si
        else:
            pass
            '''print("the word: %s is not in my Vocabulary!" % word)'''
    return returnVec

#计算问句和每一个语料库中问题的相似度，合成一个列表
def Similarity(wordVecs,S_in):
    Simlist = []
    for S in wordVecs:
        try:
            Sim = (np.sum(np.multiply(S,S_in)))/(np.linalg.norm(S) * np.linalg.norm(S_in))
        except:
            Sim = 0.01
        Simlist.append(Sim)
    return Simlist
