# -*- coding:utf-8 -*-
import pandas as pd
import numpy as np
import jieba as jb
import jieba.posseg as pseg  # 词性标注库
import jieba.analyse  # 基于 TF-IDF 算法
from math import log
from data_base.database import DbConnect
import json

# 引入中文停用词库，进行过滤
def filtration(ls):  # 单个问题列表
    file = open('words_filtered_library.txt', 'r', encoding='utf8')
    t = file.readlines()
    ls_copy = ls.copy()
    for i in range(len(t)):
        t[i] = t[i].replace('\n', '')  # 去除停用词库中每行末尾的\n
    for i in ls_copy:
        if i in t:
            ls.remove(i)
    file.close()
    return ls

# 得到FAQ中问题方面的信息,包括问题总数.传入参数为语料库readlines后的列表
def info_Q(txt_lines):
    Q_list = []
    for line in txt_lines:
        if line[0] == 'Q':
            line = line.replace('\n', '')
            Q_list.append(line)
    return Q_list  # 这里Q_list中每个问题末尾都不含有\n

# 加载文件,返回问题列表
def loadDataSet():
    f = open('./QA_DATA/QASET2.txt', 'r', encoding='utf8')
    t = f.readlines()
    Q_list = info_Q(t)
    postingList = []  # 每个元素为问题分词后的列表
    for q in Q_list:
        q_l = list(q)
        if ':' in q_l:  # 英文字符:
            del q_l[0:q_l.index(':') + 1:1]
        elif '：' in q_l:  # 中文字符冒号
            del q_l[0:q_l.index('：') + 1:1]
        q = ''.join(q_l)  # 之前几步是为了将Qxxx及：删除

        q = jb.lcut(q)  # 对每条问题进行分词
        postingList.append(q)
    for i in range(len(postingList)):
        postingList[i] = filtration(postingList[i])  # 去除停用词后的新postingList

    # 该出之后可以添加分类部分代码
    f.close()
    return postingList, Q_list

# 获得词汇列表
def createVocabList(dataSet):  # 一个大列表，里面有小列表。postingList
    vocabSet = set([])
    for document in dataSet:
        vocabSet = vocabSet | set(document)  # 创建两个集合的并集
    return list(vocabSet)

#创建k_List列表
def create_k_List(vocabList):
    k_List = vocabList.copy()
    vocabString = ' '.join(k_List)
    keys = jb.analyse.extract_tags(vocabString, topK=3,
                                      allowPOS=('n', 'nr', 'ns', 'nt', 'nz', 'vn', 'ni', 'nl'))  # 返回的是主题词列表,设定只返回名词类型
    for key in keys:
        k_List[k_List.index(key)] = 1.0  # 主题词的权重被设为1
    f = open('QA_DATA/KEY_WORDS.txt', 'r', encoding='utf8')  # 问点词词库
    ls = f.read().split(',')  # 问点词列表,每个元素都是一个问点词
    f.close()
    for i in k_List:
        if i in ls:
            k_List[k_List.index(i)] = 0.9  # 问点词的权重被设为0.9
        elif i != 1.0:
            k_List[k_List.index(i)] = 0.8
    return k_List

#创建idf_List列表
def create_idf_List(vocabList, postingList):
    idf_List = []  # 键为词汇表中每一个词，值为idf，即该词的反频率
    for i in vocabList:
        count = 0  # 用于计数包含词i的问句的个数
        for q in postingList:
            if i in q:
                count += 1
        try:
            idf_i = log((len(postingList) / float(count)), 10)
        except:
            idf_i = 0.1
        idf_List.append(idf_i)
    return idf_List

def create_QList(vocabList, postingList):
    Q_list = []
    for i in vocabList:
        templist = []
        for j in range(len(postingList)):
            if i in postingList[j]:
                templist.append(j)
        Q_list.append(templist)
    return Q_list


#创建词汇表
#vocabList:['大学','微积分','帅哥','无敌'], k_List:['0.8,0.9,0.8...'], idf_List:[idf1,idf2,...], Q_List:汇总含有某关键词的问题列表的列表
def build_Vocabrary(vocabList, k_List, idf_List, QList):
    df = pd.DataFrame({'vocabList':vocabList,'k_List':k_List,'idf_List':idf_List,'QList':QList})
    return df

def output_answer(q):  # 按照问题提供答案，这里我开发了txt打印指定行的算法
    f = open('QA_DATA/QASET2.txt', 'r', encoding='utf8')
    num_this_q, num_next_q = 0, 0
    count_this, count_next = 0, 0
    txtList = list(enumerate(f))
    for num, line in txtList:  # num为行号，从0开始
        if line[0] == 'Q':
            line = line.replace('\n', '')
        if line == q:
            num_this_q = num
            count_this = 1
        if line[0] == 'Q' and num > num_this_q:
            num_next_q = num
            if count_this == 1:
                count_next = 1
        if count_this == 1 and count_next == 1:
            break

    answer = ''
    for i in range(num_this_q, num_next_q):
        answer += txtList[i][1]
    f.close()
    return answer

# postingList, Q_list = loadDataSet()
# vocabList = createVocabList(postingList)
# k_List = create_k_List(vocabList)
# idf_List = create_idf_List(vocabList, postingList)
# QList = create_QList(vocabList, postingList)
# #print(postingList,'\n',vocabList)
# data = build_Vocabrary(vocabList, k_List, idf_List, QList)

# print(data['idf_List'][0])
