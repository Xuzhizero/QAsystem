from django.apps import AppConfig


class QaTestConfig(AppConfig):
    name = 'qa_test'
