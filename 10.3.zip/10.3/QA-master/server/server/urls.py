from django.contrib import admin
from django.urls import path
from . import view

urlpatterns = [
    path('hello/', view.hello),
    path('qa/<str:question>', view.qa, name='bio'),
]
