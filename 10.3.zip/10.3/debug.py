# -*- coding:utf-8 -*-

from original import *
import sheet
from temp1 import *
from data_base.data_get import * 

'''
postingList, Q_list = loadDataSet()
vocabList = createVocabList(postingList)
k_List = create_k_List(vocabList)
idf_List = create_idf_List(vocabList, postingList)
QList = create_QList(vocabList, postingList)
#print(postingList,'\n',vocabList)
Vocabrary = build_Vocabrary(vocabList, k_List, idf_List, QList)
print(Vocabrary)

Qdict2List = sheet.create_Qdict2List(postingList, Vocabrary)
Answerlist = sheet.create_Answerlist(Q_list)
sheet2 = sheet.build_sheet2(Qdict2List, Answerlist)
#print(sheet2)
'''

if __name__ == "__main__":
    quest = question_get()

    key = extract_key_word(quest)
    #获取 词数据列表，问题id列表， 问题数据列表
    key_list, quest_list, q_v_list = qa_db_fetch(key)
    print(key_list,'\n',quest_list,'\n','q_v_list')
