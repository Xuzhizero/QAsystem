#!/usr/bin/env python 
# -*- coding:utf-8 -*-
import jieba as jb

import preprocessing as pre

#终端程序，目前用于人工输入问题
#以下两个函数为输入端函数
def question_get(): # get questions
    q = input("你的问题是什么?\n")
    return q

def extract_key_word(question): #提取出关键词，合放在一个列表中
    ls = jb.lcut(question)
    ls = pre.filtration(ls)
    return ls  #这是一个列表
