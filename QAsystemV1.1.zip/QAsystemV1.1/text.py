#!/usr/bin/env python 
# -*- coding:utf-8 -*-

#用于检测两个相同的问题相似度是否为1.0
'''
    if q_possible_1st == q:
        print('True1')
    if S_in == wordVecs[Series_Simlist.idxmax()]:
        print('True2')
    else:
        Sim = (np.sum(np.multiply(wordVecs[Series_Simlist.idxmax()], S_in))) / (np.linalg.norm(wordVecs[Series_Simlist.idxmax()]) * np.linalg.norm(S_in))
        print(Sim)
        print(S_in)
        print(wordVecs[Series_Simlist.idxmax()])
'''