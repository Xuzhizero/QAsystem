#!/usr/bin/env python 
# -*- coding:utf-8 -*-



#想要去掉Qxxx，可以用一个冒号标记。由于到目前为止，Qxxx之后没有冒号，因此想批量增加冒号
def birth_colon():
    nums = ['0','1','2','3','4','5','6','7','8','9']
    f = open('语料库整理\问答语料对.txt','r')
    t = f.readlines()
    for line in t:
        if line[0] == 'Q':
            for i in range(1,len(line)):
                if line[i] in nums and line[i+1] not in nums:
                    line_l = list(line)
                    line_l.insert(i+1,':')
                    line_add = ''.join(line_l)
                    t[t.index(line)] = line_add
                    break
    f.close()
    t = ''.join(t)
    f2 = open('语料库整理\问答语料对2.txt','w')
    f2.write(t)
    f2.close()
    print('冒号添加成功!')

birth_colon()