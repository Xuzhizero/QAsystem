#!/usr/bin/env python 
# -*- coding:utf-8 -*-




#用于自动输入问题

def q_auto_in(): #删除末尾换行符，同时去掉Qxxx:
    f = open('语料库整理\q.txt','r')
    t = f.readlines()
    for i in range(len(t)):
        t[i] = t[i].replace('\n','')
    for i in range(len(t)):
        q_l = list(t[i])
        if ':' in q_l: #英文字符:
            del q_l[0:q_l.index(':')+1:1]
        elif '：' in q_l: #中文字符冒号
            del q_l[0:q_l.index('：') + 1:1]
        t[i] = ''.join(q_l)    #之前几步是为了将Qxxx及：删除
    f.close()
    return t #测试集readlines列表，去掉了末尾的换行符






